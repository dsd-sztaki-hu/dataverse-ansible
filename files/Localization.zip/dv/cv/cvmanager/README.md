## CVManager is API endpoint extension of Dataverse to support CESSDA controlled vocabularies
This software is developed and supported by the [DANS](http://dans.knaw.nl) in the collaboration with [GESIS](https://www.gesis.org)
